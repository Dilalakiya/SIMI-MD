# Selfkiller - Powerful Mobile Malware Toolkit

![Selfkiller Logo](https://l.top4top.io/p_2656q9nit0.jpg)

## Introduction

Selfkiller is a comprehensive mobile malware toolkit that allows users to create powerful viruses with stealth capabilities. Please note that this toolkit is intended for educational and research purposes only. The use of malicious software is illegal and unethical. 

## Features

- **Stealthy Operation**: Many antivirus programs may not detect the viruses created using Selfkiller, making it a potent tool for testing security measures.
- **Diverse Functions**: Selfkiller allows you to delete important files, change wallpaper, and play background music on the target device, demonstrating the range of malicious actions that can be performed.

## Supported Platforms

Selfkiller is compatible with the following platforms:

- [Termux App](https://termux.com)
- [Parrot OS](https://www.parrotsec.org)
- [Kali Linux](https://www.kali.org)

## Requirements

### Termux App

In Termux, grant storage permissions using the following command:

```shell
termux-setup-storage
```

## Getting Started

<i>To begin using Selfkiller, follow these steps:</i>

### INSTALLATION

```
git clone https://github.com/GH05T-HUNTER5/selfkiller
```

```
cd selfkiller
```

```
chmod +x selfkiller
```

```
python3 install.py
```

```
selfkiller
```

Or 

```
./selfkiller
```

## Important Note

<i>This toolkit is for educational and research purposes only. The use of Selfkiller for malicious activities is strictly prohibited and illegal. The developers assume no liability for any misuse or damage caused by this program.</i>

## Disclaimer

The use of Selfkiller is the complete responsibility of the end-user. Developers assume no liability and are not responsible for any misuse or damage caused by this program.


